<?php

require_once "db_config.php";

function insertData($name, $age, $mobile, $email, $image){
    global $db;
    $sql = "INSERT INTO users (name, age, mobile, email, image) VALUES('$name', '$age', '$mobile', '$email', '$image')";
    $result = mysqli_query($db, $sql) or die(mysqli_error($db));
    return $result;
}

function displayAll(){
    global $db;
    $sql = "SELECT * FROM users";
    $result = mysqli_query($db, $sql) or die(mysqli_error($db));
    return $result;
}

function deleteData($id){
    global $db;
    $sql = "DELETE FROM users WHERE id = '$id'";
    $result = mysqli_query($db, $sql) or die(mysqli_error($db));
    return $result;
}

function updateData($id, $name, $age, $mobile, $email){
    global $db;
    $sql = "UPDATE `users` SET `name`='$name', `age`='$age', `mobile`='$mobile', `email`='$email' WHERE id = '$id'";
    $result = mysqli_query($db, $sql);
    return $result;
}