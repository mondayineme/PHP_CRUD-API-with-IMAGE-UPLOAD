<?php
require_once "db_function.php";
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Getting post data
    $id = $_POST['id'];

if (isset($_POST['id'])) {
    
    $result = deleteData($id);

    if ($result) {
        $response['success'] = 1;
        $response['message'] = "Data deleted successfully..";
        echo json_encode($response);
    }else{
        $response['success'] = 0;
        $response['message'] = "Try Again";
        echo json_encode($response);
    }
}else{
    $response['success'] = 0;
    $response['message'] = "Required Fields are missing";
    echo json_encode($response);
}

if($db == true){
    mysqli_close($db);
}

}else{
    $response['success'] = 0;
    $response['message'] = "Invalid Request!";
    echo json_encode($response);
}